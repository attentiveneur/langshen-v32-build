import SwiftUI
import AVFoundation
import UIKit

// ============================================================
// v21.0 · 启动视频 + 卡密验证门
// 1. 全屏播放包内 splash.mp4（120 帧原片），播完定格在最后一帧
// 2. 定格画面上叠卡密验证页：输入 → 服务端校验 → 进去了
// 3. 验过一次就记住（钥匙串），下次启动直接进；到期或被停用就锁回来
// ============================================================

struct SplashLicenseGateView: View {
    @EnvironmentObject private var license: LicenseManager
    /// 视频已经播过了（比如到期后被锁回来）就不再重播，直接出输入框
    var skipVideo: Bool = false
    /// 视频播完 / 兜底超时时通知外层：可以进主界面了
    var onVideoEnd: () -> Void = {}
    @State private var key = ""
    @State private var videoDone = false
    @FocusState private var keyFocused: Bool

    // v25.0 · 后台「卡密窗口」改的样式，进来就拉一次，拉不到用上次缓存的
    @StateObject private var themeStore = LicenseThemeStore.shared
    private var th: LicenseTheme { themeStore.theme }

    // 这三个色名字没改，值改成后台可配的（后台没配就是原来那套霓虹绿）
    private var cyan: Color { LSThemeColor.color(th.primary, fallback: Color(red: 0.16, green: 0.92, blue: 0.52)) }
    private var cyanDeep: Color { LSThemeColor.color(th.secondary, fallback: Color(red: 0.07, green: 0.64, blue: 0.56)) }
    private var accentTail: Color { LSThemeColor.color(th.accent, fallback: Color(red: 0.56, green: 0.44, blue: 0.96)) }
    private var inputInk: Color { LSThemeColor.color(th.inputText, fallback: Color.black.opacity(0.86)) }
    /// 后台配了背景图就用它的尺寸判断：手机铺满、平板居中不裁
    private var customBG: UIImage? { themeStore.backgroundImage }
    private var customLogo: UIImage? { themeStore.logoImage }

    private var trimmedKey: String {
        key.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        GeometryReader { geo in
            // v32.0 · 手机 / 平板 / 横屏统一规则：内容永远收成一列居中，
            // 平板不拉伸、横屏不加宽，只把上下留白放大一点。
            let wide = geo.size.width >= 700
            let columnMax: CGFloat = wide ? 520 : .infinity
            let sidePad: CGFloat = wide ? 34 : 26
            let skin = LicenseStyleBook.skin(for: th)

            ZStack {
                backdrop(skin: skin)

                ScrollView(showsIndicators: false) {
                    contentColumn(skin: skin, wide: wide)
                        .padding(.horizontal, sidePad)
                        .frame(maxWidth: columnMax)
                        .frame(maxWidth: .infinity)
                }
                .scrollDismissesKeyboard(.interactively)

                if license.state == .checking {
                    checkingOverlay(skin: skin)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onAppear {
            // v25.0 · 后台改了就换：拉不到就继续用上次缓存的（不挡人）
            Task { await themeStore.refresh() }
            if skipVideo {
                videoDone = true
            } else {
                // 视频加载失败 / 卡住时的兜底，别把用户永远卡在黑屏
                DispatchQueue.main.asyncAfter(deadline: .now() + 17) {
                    finishVideo()
                }
            }
        }
        .onChange(of: skipVideo) { done in
            // v27.0 · 开场过场一结束就停片，别在输入框后面一直动
            if done { finishVideo() }
        }
        .preferredColorScheme(LicenseStyleBook.skin(for: th).light ? .light : .dark)
    }

    // MARK: - 背景（浅色版式不叠视频，避免糊成一片）

    @ViewBuilder
    private func backdrop(skin: LicenseSkin) -> some View {
        ZStack {
            LinearGradient(
                colors: [skin.bgTop, skin.bgMid, skin.bgBottom],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            if skin.bgIsLight {
                // 浅色模板：干净底 + 顶部一点主色光晕，不铺视频
                RadialGradient(
                    colors: [skin.accent.opacity(0.16), .clear],
                    center: .top,
                    startRadius: 8,
                    endRadius: 420
                )
                .ignoresSafeArea()
                .allowsHitTesting(false)
            } else {
                if let bg = customBG {
                    LSFillImage(image: bg)
                        .ignoresSafeArea()
                        .opacity(videoDone ? 1 : 0)
                        .animation(.easeOut(duration: 0.6), value: videoDone)
                        .allowsHitTesting(false)
                }

                if !skipVideo {
                    SplashVideoBackground(onFinished: { finishVideo() })
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .ignoresSafeArea()
                        .opacity(customBG != nil && videoDone ? 0 : 1)
                        .animation(.easeOut(duration: 0.6), value: videoDone)
                        .allowsHitTesting(false)
                }

                LinearGradient(
                    colors: [
                        Color.black.opacity(th.dim * 0.55),
                        Color.black.opacity(th.dim),
                        Color.black.opacity(min(0.96, th.dim * 1.42))
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                .allowsHitTesting(false)
            }
        }
    }

    // MARK: - 六种版式骨架

    @ViewBuilder
    private func contentColumn(skin: LicenseSkin, wide: Bool) -> some View {
        switch skin.layout {
        case .card:     cardLayout(skin, wide)
        case .bare:     bareLayout(skin, wide)
        case .band:     bandLayout(skin, wide)
        case .stripe:   stripeLayout(skin, wide)
        case .split:    splitLayout(skin, wide)
        case .terminal: terminalLayout(skin, wide)
        }
    }

    /// ① 卡片式：标题在上，表单整块装进一张卡
    private func cardLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        VStack(spacing: 0) {
            titleBlock(skin, alignment: skin.alignLeft ? .leading : .center)
                .padding(.top, wide ? 42 : 30)

            formBlock(skin: skin)
                .padding(.horizontal, 22)
                .padding(.vertical, 24)
                .background(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .fill(skin.cardFill)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .stroke(skin.cardStroke, lineWidth: 1)
                )
                .padding(.top, 26)

            tailBlock(skin)
        }
    }

    /// ② 裸版式：不套卡片，元素直接铺在背景上
    private func bareLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        VStack(spacing: 0) {
            titleBlock(skin, alignment: skin.alignLeft ? .leading : .center)
                .padding(.top, wide ? 64 : 50)
            formBlock(skin: skin)
                .padding(.top, 40)
            tailBlock(skin)
        }
    }

    /// ③ 色带式：上半彩色带 + 下半浅色内容区（原生设置 / 极简白）
    private func bandLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        VStack(spacing: 0) {
            VStack(spacing: 10) {
                decorView(skin)
                Text(th.title)
                    .font(.system(size: 30, weight: .heavy))
                    .foregroundStyle(Color.white)
                    .multilineTextAlignment(.center)
                Text(th.subtitle)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.86))
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 20)
            .padding(.top, wide ? 40 : 30)
            .padding(.bottom, wide ? 34 : 26)
            .background(
                LinearGradient(
                    colors: [skin.accent, skin.accent2],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )

            formBlock(skin: skin)
                .padding(.horizontal, 20)
                .padding(.vertical, 22)
                .background(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .fill(skin.light ? Color.white : Color.white.opacity(0.10))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .stroke(skin.light ? Color.black.opacity(0.07) : Color.white.opacity(0.12), lineWidth: 1)
                )
                .padding(.top, 22)

            tailBlock(skin)
        }
        .padding(.top, wide ? 40 : 0)
    }

    /// ④ 竖条式：左侧一条主色竖条，右侧内容左对齐
    private func stripeLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        HStack(alignment: .top, spacing: 0) {
            RoundedRectangle(cornerRadius: 3, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [skin.accent, skin.accent3],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: 6)
                .shadow(color: skin.accent.opacity(0.5), radius: 10)

            VStack(alignment: .leading, spacing: 0) {
                titleBlock(skin, alignment: .leading)
                    .padding(.top, wide ? 40 : 30)

                formBlock(skin: skin)
                    .padding(.top, 34)

                tailBlock(skin)
            }
            .padding(.leading, 20)
        }
        .padding(.top, wide ? 34 : 22)
    }

    /// ⑤ 上下分离：标题独占上半，表单卡片独立在下
    private func splitLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        VStack(spacing: 0) {
            VStack(spacing: 12) {
                decorView(skin)
                Text(th.title)
                    .font(.system(size: 32, weight: .heavy))
                    .foregroundStyle(skin.ink)
                    .multilineTextAlignment(.center)
                Text(th.subtitle)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(skin.ink2)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, wide ? 58 : 44)

            formBlock(skin: skin)
                .padding(.horizontal, 22)
                .padding(.vertical, 24)
                .background(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .fill(skin.cardFill)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                        .stroke(skin.cardStroke, lineWidth: 1)
                )
                .padding(.top, wide ? 42 : 32)

            tailBlock(skin)
        }
    }

    /// ⑥ 终端式：等宽、左对齐、提示符开头
    private func terminalLayout(_ skin: LicenseSkin, _ wide: Bool) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("$ langshen --verify")
                .font(.system(size: 12, weight: .medium, design: .monospaced))
                .foregroundStyle(skin.accent.opacity(0.85))
                .padding(.top, wide ? 52 : 38)

            Rectangle()
                .fill(skin.accent.opacity(0.28))
                .frame(height: 1)
                .padding(.top, 10)

            titleBlock(skin, alignment: .leading)
                .padding(.top, 22)

            formBlock(skin: skin)
                .padding(.top, 26)

            Text("> awaiting license …")
                .font(.system(size: 11, weight: .regular, design: .monospaced))
                .foregroundStyle(skin.ink3)
                .padding(.top, 14)

            tailBlock(skin)
        }
    }

    // MARK: - 组件

    /// 装饰 + 标题 + 副标题
    @ViewBuilder
    private func titleBlock(_ skin: LicenseSkin, alignment: HorizontalAlignment) -> some View {
        VStack(alignment: alignment, spacing: 0) {
            decorView(skin)

            Text(th.title)
                .font(.system(size: 34, weight: .heavy))
                .foregroundStyle(skin.ink)
                .multilineTextAlignment(alignment == .leading ? .leading : .center)
                .padding(.top, hasDecor(skin) ? 16 : 4)

            Text(th.subtitle)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(skin.ink2)
                .multilineTextAlignment(alignment == .leading ? .leading : .center)
                .padding(.top, 7)
        }
        .frame(maxWidth: .infinity, alignment: alignment == .leading ? .leading : .center)
    }

    private func hasDecor(_ skin: LicenseSkin) -> Bool {
        customLogo != nil || skin.decor != .none
    }

    /// 表单：分区标题 + 输入框 + 按钮 + 提示 + 页脚
    @ViewBuilder
    private func formBlock(skin: LicenseSkin) -> some View {
        let align: HorizontalAlignment = skin.alignLeft ? .leading : .center
        VStack(alignment: align, spacing: 0) {
            Text(th.section)
                .font(skin.mono
                      ? .system(size: 13, weight: .semibold, design: .monospaced)
                      : .system(size: 15, weight: .semibold))
                .foregroundStyle(skin.ink2)
                .frame(maxWidth: .infinity, alignment: skin.alignLeft ? .leading : .center)

            VStack(alignment: .leading, spacing: 9) {
                Text(th.fieldLabel)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(skin.ink2)

                inputField(skin: skin)
            }
            .padding(.top, 16)

            actionButton(skin: skin)
                .padding(.top, 20)

            if let text = statusText {
                statusBox(text, skin: skin)
                    .padding(.top, 14)
            }

            Text(th.footer)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(skin.ink3)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity, alignment: skin.alignLeft ? .leading : .center)
                .padding(.top, 18)

            if license.state == .expired || license.hasSavedCode {
                Button("换一个卡密") {
                    license.deactivate()
                    key = ""
                }
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(skin.accent.opacity(0.90))
                .buttonStyle(.plain)
                .padding(.top, 12)
            }
        }
        .frame(maxWidth: .infinity, alignment: skin.alignLeft ? .leading : .center)
    }

    /// 输入框：四种形状
    @ViewBuilder
    private func inputField(skin: LicenseSkin) -> some View {
        let font: Font = skin.mono
            ? .system(size: 16, weight: .medium, design: .monospaced)
            : .system(size: 16, weight: .medium)

        TextField(th.placeholder, text: $key)
            .focused($keyFocused)
            .keyboardType(.asciiCapable)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
            .submitLabel(.done)
            .onSubmit { submit() }
            .onChange(of: key) { newValue in
                let cleaned = newValue.uppercased().filter { !$0.isWhitespace }
                if cleaned != newValue { key = cleaned }
            }
            .font(font)
            .foregroundStyle(skin.fieldText)
            .tint(skin.accent2)
            .multilineTextAlignment(skin.alignLeft ? .leading : .center)
            .padding(.horizontal, 18)
            .frame(height: skin.field == .underline ? 48 : 54)
            .background(fieldBackground(skin: skin))
            .overlay(fieldOverlay(skin: skin))
    }

    @ViewBuilder
    private func fieldBackground(skin: LicenseSkin) -> some View {
        switch skin.field {
        case .rounded:
            RoundedRectangle(cornerRadius: max(6, skin.corner - 1), style: .continuous)
                .fill(skin.fieldFill)
        case .pill:
            Capsule(style: .continuous).fill(skin.fieldFill)
        case .rect:
            Rectangle().fill(skin.fieldFill)
        case .underline:
            Color.clear
        }
    }

    @ViewBuilder
    private func fieldOverlay(skin: LicenseSkin) -> some View {
        switch skin.field {
        case .rounded:
            RoundedRectangle(cornerRadius: max(6, skin.corner - 1), style: .continuous)
                .stroke(skin.accent.opacity(0.60), lineWidth: 1.2)
        case .pill:
            Capsule(style: .continuous).stroke(skin.accent.opacity(0.60), lineWidth: 1.2)
        case .rect:
            Rectangle().stroke(skin.accent.opacity(0.55), lineWidth: 1.2)
        case .underline:
            VStack {
                Spacer()
                Rectangle()
                    .fill(skin.accent.opacity(0.75))
                    .frame(height: 1.4)
            }
        }
    }

    /// 按钮：四种形状
    @ViewBuilder
    private func actionButton(skin: LicenseSkin) -> some View {
        Button(action: submit) {
            HStack(spacing: 9) {
                if license.isBusy {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(skin.button == .outline ? skin.accent : .white)
                        .scaleEffect(0.85)
                }
                Text(license.isBusy ? "验证中…" : th.button)
                    .font(.system(size: 17, weight: .bold))
                    .tracking(0.5)
            }
            .foregroundStyle(buttonTextColor(skin))
            .frame(maxWidth: .infinity, minHeight: 56)
            .background(buttonBackground(skin: skin))
            .overlay(buttonOverlay(skin: skin))
            .shadow(color: skin.button == .outline ? Color.clear : skin.accent.opacity(0.35),
                    radius: 16, y: 7)
        }
        .buttonStyle(.plain)
        .disabled(trimmedKey.isEmpty || license.isBusy)
        .opacity(trimmedKey.isEmpty ? 0.55 : 1)
    }

    private func buttonTextColor(_ skin: LicenseSkin) -> Color {
        if skin.button == .outline { return skin.accent }
        if skin.light && skin.grad == false { return Color.white }
        return .white
    }

    @ViewBuilder
    private func buttonBackground(skin: LicenseSkin) -> some View {
        switch skin.button {
        case .pill:
            Capsule(style: .continuous).fill(buttonFill(skin: skin))
        case .rounded:
            RoundedRectangle(cornerRadius: skin.corner, style: .continuous)
                .fill(buttonFill(skin: skin))
        case .rect:
            Rectangle().fill(buttonFill(skin: skin))
        case .outline:
            Capsule(style: .continuous).fill(Color.clear)
        }
    }

    private func buttonFill(skin: LicenseSkin) -> AnyShapeStyle {
        if skin.grad {
            return AnyShapeStyle(LinearGradient(
                colors: [skin.accent, skin.accent3],
                startPoint: .leading,
                endPoint: .trailing
            ))
        }
        return AnyShapeStyle(skin.accent)
    }

    @ViewBuilder
    private func buttonOverlay(skin: LicenseSkin) -> some View {
        if skin.button == .outline {
            Capsule(style: .continuous)
                .stroke(skin.accent.opacity(0.85), lineWidth: 1.6)
        }
    }

    /// 页脚 + 版权
    @ViewBuilder
    private func tailBlock(_ skin: LicenseSkin) -> some View {
        VStack(spacing: 0) {
            Spacer(minLength: 40)
            Text(th.copyright)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(skin.ink3)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 30)
        }
    }

    @ViewBuilder
    private func decorView(_ skin: LicenseSkin) -> some View {
        if let logo = customLogo {
            Image(uiImage: logo)
                .resizable()
                .scaledToFit()
                .frame(width: 84, height: 84)
                .shadow(color: skin.accent.opacity(0.42), radius: 18, y: 8)
        } else {
            switch skin.decor {
            case .shield: shieldIcon(skin)
            case .lock:   lockIcon(skin)
            case .ring:   ringIcon(skin)
            case .grid:   gridIcon(skin)
            case .dots:   dotsIcon(skin)
            case .none:   EmptyView()
            }
        }
    }

    private func shieldIcon(_ skin: LicenseSkin) -> some View {
        ZStack {
            LSHexShield()
                .fill(
                    LinearGradient(
                        colors: [skin.accent.opacity(0.98), skin.accent2],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 78, height: 90)
                .shadow(color: skin.accent.opacity(0.50), radius: 20, y: 8)

            Image(systemName: "checkmark")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white.opacity(0.96))
                .offset(y: -3)
        }
    }

    private func lockIcon(_ skin: LicenseSkin) -> some View {
        ZStack {
            Circle()
                .fill(skin.accent.opacity(0.13))
                .frame(width: 96, height: 96)
            Circle()
                .stroke(skin.accent.opacity(0.45), lineWidth: 1.2)
                .frame(width: 96, height: 96)
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(skin.accent)
        }
        .shadow(color: skin.accent.opacity(0.35), radius: 18, y: 6)
    }

    private func ringIcon(_ skin: LicenseSkin) -> some View {
        ZStack {
            Circle()
                .stroke(
                    LinearGradient(colors: [skin.accent, skin.accent3],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    lineWidth: 5
                )
                .frame(width: 88, height: 88)
            Circle()
                .fill(skin.accent.opacity(0.18))
                .frame(width: 58, height: 58)
            Circle()
                .fill(skin.accent)
                .frame(width: 16, height: 16)
        }
        .shadow(color: skin.accent.opacity(0.50), radius: 18)
    }

    private func gridIcon(_ skin: LicenseSkin) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(skin.accent.opacity(0.40), lineWidth: 1.2)
                .frame(width: 90, height: 90)
            VStack(spacing: 6) {
                ForEach(0..<3, id: \.self) { _ in
                    HStack(spacing: 6) {
                        ForEach(0..<3, id: \.self) { _ in
                            Rectangle()
                                .fill(skin.accent.opacity(0.55))
                                .frame(width: 14, height: 14)
                        }
                    }
                }
            }
        }
        .shadow(color: skin.accent.opacity(0.30), radius: 14)
    }

    private func dotsIcon(_ skin: LicenseSkin) -> some View {
        HStack(spacing: 9) {
            ForEach(0..<5, id: \.self) { i in
                Circle()
                    .fill(skin.accent.opacity(i == 2 ? 1.0 : 0.34))
                    .frame(width: i == 2 ? 13 : 8, height: i == 2 ? 13 : 8)
            }
        }
        .frame(height: 20)
    }

    private var statusText: String? {
        if let message = license.message, !message.isEmpty { return message }
        return nil
    }

    private func statusBox(_ text: String, skin: LicenseSkin) -> some View {
        Text(text)
            .font(.system(size: 12.5, weight: .semibold))
            .foregroundStyle(skin.light
                             ? Color(red: 0.75, green: 0.16, blue: 0.16)
                             : Color(red: 1.0, green: 0.62, blue: 0.62))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 14)
            .padding(.vertical, 11)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(skin.light ? Color.black.opacity(0.05) : Color.white.opacity(0.10))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(skin.light ? Color.black.opacity(0.08) : Color.white.opacity(0.12), lineWidth: 1)
            )
    }

    private func checkingOverlay(skin: LicenseSkin) -> some View {
        VStack(spacing: 10) {
            ProgressView().tint(skin.accent)
            Text("正在核对授权…")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(skin.ink2)
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func finishVideo() {
        guard !videoDone else { return }
        withAnimation(.easeOut(duration: 0.45)) {
            videoDone = true
        }
        onVideoEnd()
    }

    private func submit() {
        let code = trimmedKey
        guard !code.isEmpty, !license.isBusy else { return }
        keyFocused = false
        Task { await license.activate(code: code) }
    }
}

/// 六边形盾牌 —— 图上那个标的形状
struct LSHexShield: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        p.move(to: CGPoint(x: rect.minX + w * 0.50, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.94, y: rect.minY + h * 0.18))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.94, y: rect.minY + h * 0.56))
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.50, y: rect.minY + h),
            control: CGPoint(x: rect.minX + w * 0.86, y: rect.minY + h * 0.84)
        )
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.06, y: rect.minY + h * 0.56),
            control: CGPoint(x: rect.minX + w * 0.14, y: rect.minY + h * 0.84)
        )
        p.addLine(to: CGPoint(x: rect.minX + w * 0.06, y: rect.minY + h * 0.18))
        p.closeSubpath()
        return p
    }
}

/// 盾牌形状（上宽下尖，和验证页顶部那个标一致）
struct LSSplashShield: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        p.move(to: CGPoint(x: rect.minX + w * 0.17, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.83, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w, y: rect.minY + h * 0.16))
        p.addLine(to: CGPoint(x: rect.minX + w, y: rect.minY + h * 0.55))
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.5, y: rect.minY + h),
            control: CGPoint(x: rect.minX + w * 0.86, y: rect.minY + h * 0.84)
        )
        p.addQuadCurve(
            to: CGPoint(x: rect.minX, y: rect.minY + h * 0.55),
            control: CGPoint(x: rect.minX + w * 0.14, y: rect.minY + h * 0.84)
        )
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + h * 0.16))
        p.closeSubpath()
        return p
    }
}

// MARK: - 视频背景（播完定格最后一帧）

/// v27.0 · 已授权时的纯开场过场：只播启动片，不显示任何输入框
struct SplashOpeningView: View {
    var body: some View {
        ZStack {
            // v31.0 · 不再是纯黑：和系统启动屏同一个品牌深墨绿，视频没起来时也不会「黑一下」
            Color(red: 0x06 / 255.0, green: 0x14 / 255.0, blue: 0x0C / 255.0)
            SplashVideoBackground()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .ignoresSafeArea()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SplashVideoBackground: UIViewRepresentable {
    var onFinished: (() -> Void)? = nil
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> SplashVideoPlayerView {
        let view = SplashVideoPlayerView()
        context.coordinator.handler = onFinished
        view.onFinished = { context.coordinator.fire() }
        return view
    }

    func updateUIView(_ uiView: SplashVideoPlayerView, context: Context) {
        context.coordinator.handler = onFinished
        uiView.startIfNeeded()
    }

    final class Coordinator {
        var handler: (() -> Void)?
        private var fired = false

        func fire() {
            guard !fired else { return }
            fired = true
            handler?()
        }
    }
}

final class SplashVideoPlayerView: UIView {
    // v26.0 · 真满屏覆盖
    // 手机竖屏走竖版启动片 splash.mp4，iPad 竖屏 / 所有横屏自动换横版启动片 splashWide.mp4，
    // 两者都是「铺满整屏 + 裁掉多余边」，不再有居中留边，也不再有模糊垫底，任何比例都不露白、不拉伸变形。
    //
    // v31.0 · 治「进软件先黑一下」：
    //   1) 底色不再是纯黑，换成和系统启动屏同一个品牌色（#06140C），冷启动到入场全程一色，肉眼看不到断层
    //   2) 视频解码出第一帧之前，先把片子第一帧的静态图（SplashFirst / SplashFirstWide）画上去，
    //      起播再慢用户看到的也是画面，不是黑屏；视频就绪后再 0.2 秒淡入接管
    //   3) 关闭自动等待缓冲 + 只缓冲 1 秒，起播更快
    private let playerLayer = AVPlayerLayer()
    private let posterView = UIImageView()
    private var player: AVPlayer?
    private var playerItem: AVPlayerItem?
    private var endObserver: NSObjectProtocol?
    private var statusObservation: NSKeyValueObservation?
    private var started = false
    private var posterApplied = false
    /// 品牌深墨绿，和 Info.plist 里的 LaunchBg 完全一致
    static let brandInk = UIColor(red: 0x06 / 255.0, green: 0x14 / 255.0, blue: 0x0C / 255.0, alpha: 1)
    /// 播完并定格后回调一次
    var onFinished: (() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private var isWideLayout: Bool {
        let ratio = bounds.width / max(bounds.height, 1)
        return ratio > (9.0 / 16.0) * 1.25
    }

    private func setup() {
        backgroundColor = Self.brandInk
        clipsToBounds = true
        isUserInteractionEnabled = false

        posterView.contentMode = .scaleAspectFill
        posterView.clipsToBounds = true
        posterView.backgroundColor = Self.brandInk
        posterView.isUserInteractionEnabled = false
        addSubview(posterView)

        playerLayer.videoGravity = .resizeAspectFill
        playerLayer.opacity = 0          // 第一帧就绪后再淡入，避免空图层闪黑
        layer.addSublayer(playerLayer)
    }

    /// 先把启动片第一帧顶上（毫秒级，走资源目录，不用解码视频）
    private func applyPosterIfNeeded() {
        guard !posterApplied, bounds.width > 1 else { return }
        posterApplied = true
        let wide = isWideLayout
        let image = UIImage(named: wide ? "SplashFirstWide" : "SplashFirst")
            ?? UIImage(named: "SplashFirst")
            ?? UIImage(named: "SplashFirstWide")
        posterView.image = image
        if image == nil { posterView.backgroundColor = Self.brandInk }
        posterView.frame = bounds
    }

    /// 竖屏取竖版素材，宽屏取横版素材；包里缺哪个就退回另一个，永不黑屏
    private func videoURL() -> URL? {
        if isWideLayout, let u = Bundle.main.url(forResource: "splashWide", withExtension: "mp4") {
            return u
        }
        return Bundle.main.url(forResource: "splash", withExtension: "mp4")
            ?? Bundle.main.url(forResource: "splashWide", withExtension: "mp4")
    }

    func startIfNeeded() {
        guard !started else { return }
        guard bounds.width > 1, bounds.height > 1 else { return }
        started = true

        applyPosterIfNeeded()

        guard let url = videoURL() else {
            // 包里没有视频：静态首帧留着当画面，不崩、不黑、也别把用户卡在这
            DispatchQueue.main.async { [weak self] in self?.onFinished?() }
            return
        }

        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: [.mixWithOthers])

        let item = AVPlayerItem(asset: AVURLAsset(url: url))
        // 只缓冲 1 秒、不等缓冲满就起播：这两项直接影响「点开之后那一下黑屏有多久」
        item.preferredForwardBufferDuration = 1
        let p = AVPlayer(playerItem: item)
        p.isMuted = true
        p.actionAtItemEnd = .pause
        p.automaticallyWaitsToMinimizeStalling = false
        player = p
        playerItem = item
        playerLayer.player = p

        // 解码器真的就绪了再把视频层淡进来；在那之前静态首帧一直盖着，绝不会出现黑场
        statusObservation = item.observe(\.status, options: [.new, .initial]) { [weak self] observed, _ in
            guard observed.status == .readyToPlay else { return }
            DispatchQueue.main.async {
                guard let self else { return }
                // 再给解码器一帧的时间，确保淡入时已经有画面
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                    UIView.animate(withDuration: 0.2, delay: 0, options: [.beginFromCurrentState]) {
                        self.playerLayer.opacity = 1
                    }
                }
                self.statusObservation?.invalidate()
                self.statusObservation = nil
            }
        }

        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak p, weak item] _ in
            guard let p else { return }
            // 停在最后一帧：不循环、不黑屏
            let duration = item?.duration.seconds ?? 0
            if duration.isFinite, duration > 0.1 {
                p.seek(
                    to: CMTime(seconds: max(0, duration - 0.05), preferredTimescale: 600),
                    toleranceBefore: .zero,
                    toleranceAfter: .zero
                ) { _ in
                    p.pause()
                    self.onFinished?()
                }
            } else {
                p.pause()
                self.onFinished?()
            }
        }

        p.playImmediately(atRate: 1)
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        applyPosterIfNeeded()

        CATransaction.begin()
        CATransaction.setDisableActions(true)
        playerLayer.frame = bounds
        posterView.frame = bounds
        CATransaction.commit()

        // 尺寸出来之前拿不到屏幕比例，这里补一次启动
        if !started {
            startIfNeeded()
        }
    }

    deinit {
        statusObservation?.invalidate()
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
        }
    }
}

// MARK: - 后台自定义背景图（满屏适配）

/// 后台「卡密窗口」上传的那张图。
/// v26.0 · 不管图片什么比例，一律「铺满整屏 + 裁掉多余边」：
/// 不留白、不模糊垫底、不拉伸，手机竖屏和 iPad 横屏都是满屏。
struct LSFillImage: View {
    let image: UIImage

    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)

            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
                .scaledToFill()
                .frame(width: w, height: h)
                .clipped()
        }
    }
}
